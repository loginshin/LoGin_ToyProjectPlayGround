import styled from 'styled-components';
import { Button } from 'antd';
import React from 'react';
import 'antd/dist/antd.css';

function CommentCard(props) {
    return (
        <Card>
            <AnswerList>
                <div style={{margin: "0 auto"}}>
                    <div style={{float:"left", marginLeft:"5%", width:"4%", height:"100%", alignItems:"center", justifyContent:"center", display:"flex", flexDirection:"column"}}>
                        <Button>▲</Button>
                        <div className="LikeCount" style={{textAlign:"center", padding:"50% 0"}}>1</div>
                        <Button>▼</Button>
                    </div>

                    <UserContext>
                        안녕하세요? 저는 댓글이에요. <br></br>
                        코드도 쓸 수 있죠.<br></br><br></br><br></br>
                        ㅎㅇㅎㅇㅎㅇ<br></br><br></br><br></br>
                        ㅎㅇㅎㅇㅎㅇ
                    </UserContext>
                </div>
            </AnswerList>
        </Card>
    );
}

export default CommentCard;

const Card = styled.div`
`
const AnswerList = styled.div`
    float: left;
    width: 85%;
    min-height: 200px;
    height: auto;
    padding-top: 2%;
    padding-bottom: 2%;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
    border-top: 0;
    border-color: #f0f0f0;
`
const UserContext = styled.div`
    float: left; 
    margin-left: 5%;
    height:"100%"
`