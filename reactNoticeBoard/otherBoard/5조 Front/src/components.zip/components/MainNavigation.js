import { Link } from "react-router-dom";
import styled from "styled-components";

function MainNavigation() {
    return (
        <MainNav>
            <LayoutBox>
                <div style={{width:"100%"}}>
                    <Link to='/'><h1>일단하자</h1></Link>
                </div>
            </LayoutBox>
                 <ul style={{float:"right"}}>
                    <NavList>
                        <Link to='/signup'>회원가입</Link>
                    </NavList>
                    <NavList>
                        <Link to='/login'>로그인</Link>
                    </NavList>
                </ul>
        </MainNav>
    )
}

export default MainNavigation;

const MainNav = styled.header`
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 80px;
    padding-left: 45%;
    position: relative;
    background-color: #e1e2e3;
`;

const LayoutBox = styled.div`
`
const NavList = styled.li`
    list-style: none;
    padding-right: 70px;
    float: left;
`