import Editor from './EditorComponent2';
import { useState } from 'react';

/* eslint-disable */ 

const NoticeWriteComponent2 = () => {
    const [desc, setDesc] = useState('');
    function onEditorChange(value) {
        setDesc(value)
    }
    
    return (
        <div>
          <Editor value={desc} onChange={onEditorChange} />
        </div>
    )
};

export default NoticeWriteComponent2;